/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Array1DIMENSI;

/**
 *
 * @author Windows
 */
public class NilaiRataRata {
    public static void main(String[] args) {
        // Mendefinisikan array
        int[] numbers = {5, 10, 3, 8, 15}; // Ubah nilai sesuai kebutuhan

        // Memanggil method untuk mencari nilai rata-rata
        double average = findAverage(numbers);

        // Menampilkan hasil
        System.out.println("Rata-rata: " + average);
    }

    // Method untuk mencari nilai rata-rata dalam array
    public static double findAverage(int[] array) {
        int sum = 0;
        for (int num : array) {
            sum += num;
        }
        return (double) sum / array.length;
    }
}

