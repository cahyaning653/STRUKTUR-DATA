/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Array2DIMENSI;

/**
 *
 * @author Windows
 */
public class ARRAY {
    public class Array2DExample {
    public static void main(String[] args) {
        // Mendefinisikan array 2 dimensi dengan ukuran 3x3
        int[][] array2D = new int[3][3];

        // Menginisialisasi array 2 dimensi
        array2D[0][0] = 1;
        array2D[0][1] = 2;
        array2D[0][2] = 3;
        array2D[1][0] = 4;
        array2D[1][1] = 5;
        array2D[1][2] = 6;
        array2D[2][0] = 7;
        array2D[2][1] = 8;
        array2D[2][2] = 9;

        // Menampilkan array 2 dimensi
        System.out.println("Array 2 Dimensi:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print(array2D[i][j] + " ");
            }
            System.out.println();
        }
    }
}
}

