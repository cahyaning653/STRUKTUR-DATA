/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Perulangan;

/**
 *
 * @author HP
 */
public class LoopingFor {

    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) 
    {
        int nilai = 1;

        do 
        {
            System.out.println("nilai: " + nilai);
            nilai++;
        } while (nilai < 7);
    }
    
}
