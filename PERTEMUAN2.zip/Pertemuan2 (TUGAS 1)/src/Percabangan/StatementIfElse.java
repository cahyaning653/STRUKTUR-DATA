/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Percabangan;

/**
 *
 * @author HP
 */
public class StatementIfElse {
      public static void main(String[] args) 
    {
        int angka = 6;

        if (angka % 2 == 0) {
            System.out.println("Angka adalah bilangan genap");
        } else {
            System.out.println("Angka adalah bilangan ganjil");
        }
    }
    
}